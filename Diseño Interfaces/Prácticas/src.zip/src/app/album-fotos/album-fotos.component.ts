import { Component } from '@angular/core';

@Component({
  selector: 'boot-album-fotos',
  imports: [],
  templateUrl: './album-fotos.component.html',
  styleUrl: './album-fotos.component.css'
})
export class AlbumFotosComponent {

}
