import { Component } from '@angular/core';

@Component({
  selector: 'boot-album-videos',
  imports: [],
  templateUrl: './album-videos.component.html',
  styleUrl: './album-videos.component.css'
})
export class AlbumVideosComponent {

}
