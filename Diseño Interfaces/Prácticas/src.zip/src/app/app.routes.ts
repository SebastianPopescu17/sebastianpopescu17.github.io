import { Routes } from '@angular/router';
import { TabComponent } from './tab/tab.component';
import { SliderFotosComponent } from './slider-fotos/slider-fotos.component';
import { SliderVideosComponent } from './slider-videos/slider-videos.component';
import { AlbumFotosComponent } from './album-fotos/album-fotos.component';
import { AlbumVideosComponent } from './album-videos/album-videos.component';
import { VideosComponent } from './videos/videos.component';



export const routes: Routes = [
    { path: '', component: TabComponent},
    { path: 'slider-fotos', component: SliderFotosComponent },
    { path: 'slider-videos', component: SliderVideosComponent },
    { path: 'album-fotos', component: AlbumFotosComponent },
    { path: 'album-videos', component: AlbumVideosComponent },
    { path: 'videos', component: VideosComponent },
    { path: '**', redirectTo: '' }
  ];
  