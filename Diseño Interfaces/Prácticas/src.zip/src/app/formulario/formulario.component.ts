import { Component } from '@angular/core';

@Component({
  selector: 'boot-formulario',
  imports: [],
  templateUrl: './formulario.component.html',
  styleUrl: './formulario.component.css'
})
export class FormularioComponent {

}
