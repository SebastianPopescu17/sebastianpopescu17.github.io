import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResponsivoComponent } from './responsivo.component';

describe('ResponsivoComponent', () => {
  let component: ResponsivoComponent;
  let fixture: ComponentFixture<ResponsivoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResponsivoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResponsivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
