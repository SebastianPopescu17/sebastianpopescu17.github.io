import { Component } from '@angular/core';

@Component({
  selector: 'boot-responsivo',
  imports: [],
  templateUrl: './responsivo.component.html',
  styleUrl: './responsivo.component.css'
})
export class ResponsivoComponent {

}
