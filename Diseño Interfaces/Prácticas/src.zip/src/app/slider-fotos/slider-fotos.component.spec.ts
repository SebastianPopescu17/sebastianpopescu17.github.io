import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SliderFotosComponent } from './slider-fotos.component';

describe('SliderFotosComponent', () => {
  let component: SliderFotosComponent;
  let fixture: ComponentFixture<SliderFotosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SliderFotosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SliderFotosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
