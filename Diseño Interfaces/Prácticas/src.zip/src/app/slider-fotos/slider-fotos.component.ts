import { Component } from '@angular/core';

@Component({
  selector: 'boot-slider-fotos',
  imports: [],
  templateUrl: './slider-fotos.component.html',
  styleUrl: './slider-fotos.component.css'
})
export class SliderFotosComponent {

}
