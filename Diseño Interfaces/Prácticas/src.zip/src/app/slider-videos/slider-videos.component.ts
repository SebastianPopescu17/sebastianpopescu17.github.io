import { Component } from '@angular/core';

@Component({
  selector: 'boot-slider-videos',
  imports: [],
  templateUrl: './slider-videos.component.html',
  styleUrl: './slider-videos.component.css'
})
export class SliderVideosComponent {

}
