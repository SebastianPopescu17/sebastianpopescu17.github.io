import { Component } from '@angular/core';
import {SliderFotosComponent} from '../slider-fotos/slider-fotos.component';
import {SliderVideosComponent} from '../slider-videos/slider-videos.component';
import {AlbumVideosComponent} from '../album-videos/album-videos.component';
import {AlbumFotosComponent} from '../album-fotos/album-fotos.component';
import {VideosComponent} from '../videos/videos.component';
import {ResponsivoComponent} from '../responsivo/responsivo.component';
import { FormularioComponent } from '../formulario/formulario.component';



@Component({
  selector: 'boot-tab',
  imports: [SliderFotosComponent, SliderVideosComponent, AlbumVideosComponent, AlbumFotosComponent, VideosComponent, ResponsivoComponent, FormularioComponent],
  templateUrl: './tab.component.html',
  styleUrl: './tab.component.css'
})
export class TabComponent {

}
