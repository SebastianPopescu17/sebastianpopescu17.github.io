import { Component } from '@angular/core';

@Component({
  selector: 'boot-videos',
  imports: [],
  templateUrl: './videos.component.html',
  styleUrl: './videos.component.css'
})
export class VideosComponent {

}
